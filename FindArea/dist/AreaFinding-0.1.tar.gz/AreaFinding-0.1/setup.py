from setuptools import setup, find_packages
 
setup(name='AreaFinding',
      version='0.1',
      url='https://github.com/susmp/test_task.git',
      license='MIT',
      author='Pavlov M',
      author_email='mspavlovhse@gmail.com',
      description='Find are of different figures',
      packages=find_packages(),
      )